<!DOCTYPE html>
	<html lang="ko-KR">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>로그인 &lsaquo; 강남룸가이드 &#8212; 워드프레스</title>
	    <style>
       .login-action-lostpassword #login_error{
           display: none;
       }
    </style>
    <meta name='robots' content='max-image-preview:large, noindex, noarchive' />
<link rel='stylesheet' id='bricks-advanced-themer-css' href='https://roomguide.kr/wp-content/plugins/bricks-advanced-themer/assets/css/bricks-advanced-themer.css?ver=1735085931' media='all' />
<link rel='stylesheet' id='dashicons-css' href='https://roomguide.kr/wp-includes/css/dashicons.min.css?ver=844c8d9f2d3bd8db4ea261800fed7208' media='all' />
<link rel='stylesheet' id='buttons-css' href='https://roomguide.kr/wp-includes/css/buttons.min.css?ver=844c8d9f2d3bd8db4ea261800fed7208' media='all' />
<link rel='stylesheet' id='forms-css' href='https://roomguide.kr/wp-admin/css/forms.min.css?ver=6.9.4' media='all' />
<link rel='stylesheet' id='l10n-css' href='https://roomguide.kr/wp-admin/css/l10n.min.css?ver=6.9.4' media='all' />
<link rel='stylesheet' id='login-css' href='https://roomguide.kr/wp-admin/css/login.min.css?ver=6.9.4' media='all' />
<link rel='stylesheet' id='rsssl-profile-settings-css' href='https://roomguide.kr/wp-content/plugins/really-simple-ssl/assets/two-fa/rtl/two-fa-assets.min.css?ver=9.1.4' media='all' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="icon" href="https://roomguide.kr/wp-content/uploads/cropped-gn-roomguide-32x32.png" sizes="32x32" />
<link rel="icon" href="https://roomguide.kr/wp-content/uploads/cropped-gn-roomguide-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://roomguide.kr/wp-content/uploads/cropped-gn-roomguide-180x180.png" />
<meta name="msapplication-TileImage" content="https://roomguide.kr/wp-content/uploads/cropped-gn-roomguide-270x270.png" />
	</head>
	<body class="login no-js login-action-login wp-core-ui  locale-ko-kr">
	<script>
document.body.className = document.body.className.replace('no-js','js');
</script>

				<h1 class="screen-reader-text">로그인</h1>
			<div id="login">
		<h1 role="presentation" class="wp-login-logo"><a href="https://wordpress.org/">워드프레스 제공</a></h1>
	
		<form name="loginform" id="loginform" action="https://roomguide.kr/wp-login.php" method="post">
			<p>
				<label for="user_login">사용자명 또는 이메일 주소</label>
				<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" autocomplete="username" required="required" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">비밀번호</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" class="input password-input" value="" size="20" autocomplete="current-password" spellcheck="false" required="required" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="비밀번호 표시">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
			<p><label for="loginlockdown_captcha">Are you human? Please solve: <img class="loginlockdown-captcha-img" style="vertical-align: text-top;" src="https://roomguide.kr/wp-content/plugins/login-lockdown//libs/captcha.php?loginlockdown-generate-image=true&noise=1&rnd=4321" alt="Captcha" /><input class="input" type="text" size="3" name="loginlockdown_captcha" id="loginlockdown_captcha" /></label></p><br />			<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> <label for="rememberme">기억하기</label></p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="로그인" />
									<input type="hidden" name="redirect_to" value="https://roomguide.kr/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
				<a class="wp-login-lost-password" href="https://roomguide.kr/wp-login.php?action=lostpassword">비밀번호를 잊으셨나요?</a>			</p>
			<script>
function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }
</script>
		<p id="backtoblog">
			<a href="https://roomguide.kr/">&larr; 강남룸가이드(으)로 가기</a>		</p>
			</div>
				<div class="language-switcher">
				<form id="language-switcher" method="get">

					<label for="language-switcher-locales">
						<span class="dashicons dashicons-translation" aria-hidden="true"></span>
						<span class="screen-reader-text">
							언어						</span>
					</label>

					<select name="wp_lang" id="language-switcher-locales"><option value="en_US" lang="en" data-installed="1">English (United States)</option>
<option value="ko_KR" lang="ko" selected='selected' data-installed="1">한국어</option></select>
					
					
					
						<input type="submit" class="button" value="변경">

					</form>
				</div>
			
	    <script>
        if ( document.getElementById('login_error') ) {
            document.getElementById('user_login').value = '';
        }
    </script>
    <script src="https://roomguide.kr/wp-includes/js/clipboard.min.js?ver=2.0.11" id="clipboard-js"></script>
<script src="https://roomguide.kr/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script id="zxcvbn-async-js-extra">
var _zxcvbnSettings = {"src":"https://roomguide.kr/wp-includes/js/zxcvbn.min.js"};
//# sourceURL=zxcvbn-async-js-extra
</script>
<script src="https://roomguide.kr/wp-includes/js/zxcvbn-async.min.js?ver=1.0" id="zxcvbn-async-js"></script>
<script src="https://roomguide.kr/wp-includes/js/dist/hooks.min.js?ver=dd5603f07f9220ed27f1" id="wp-hooks-js"></script>
<script src="https://roomguide.kr/wp-includes/js/dist/i18n.min.js?ver=c26c3dc7bed366793375" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
</script>
<script id="password-strength-meter-js-extra">
var pwsL10n = {"unknown":"\ube44\ubc00\ubc88\ud638 \uac15\ub3c4 \uc54c \uc218 \uc5c6\uc74c","short":"\ub9e4\uc6b0 \uc57d\ud568","bad":"\uc57d\ud568","good":"\ubcf4\ud1b5","strong":"\uac15\ud568","mismatch":"\ubd88\uc77c\uce58"};
//# sourceURL=password-strength-meter-js-extra
</script>
<script id="password-strength-meter-js-translations">
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2026-03-26 00:20:52+0000","generator":"GlotPress\/4.0.3","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=1; plural=0;","lang":"ko_KR"},"%1$s is deprecated since version %2$s! Use %3$s instead. Please consider writing more inclusive code.":["%2$s\ubc84\uc804\ubd80\ud130 %1$s\uc744(\ub97c) \uc0ac\uc6a9\ud558\uc9c0 \uc54a\uc2b5\ub2c8\ub2e4! \ub300\uc2e0 %3$s\uc744(\ub97c) \uc0ac\uc6a9\ud558\uc138\uc694. \ub354 \ud3ec\uad04\uc801\uc778 \ucf54\ub4dc \uc4f0\uae30\ub97c \uace0\ub824\ud574\uc8fc\uc138\uc694."]}},"comment":{"reference":"wp-admin\/js\/password-strength-meter.js"}} );
//# sourceURL=password-strength-meter-js-translations
</script>
<script src="https://roomguide.kr/wp-admin/js/password-strength-meter.min.js?ver=6.9.4" id="password-strength-meter-js"></script>
<script src="https://roomguide.kr/wp-includes/js/underscore.min.js?ver=1.13.7" id="underscore-js"></script>
<script id="wp-util-js-extra">
var _wpUtilSettings = {"ajax":{"url":"/wp-admin/admin-ajax.php"}};
//# sourceURL=wp-util-js-extra
</script>
<script src="https://roomguide.kr/wp-includes/js/wp-util.min.js?ver=844c8d9f2d3bd8db4ea261800fed7208" id="wp-util-js"></script>
<script src="https://roomguide.kr/wp-includes/js/dist/dom-ready.min.js?ver=f77871ff7694fffea381" id="wp-dom-ready-js"></script>
<script id="wp-a11y-js-translations">
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2026-03-25 08:09:15+0000","generator":"GlotPress\/4.0.3","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=1; plural=0;","lang":"ko_KR"},"Notifications":["\uc54c\ub9bc"]}},"comment":{"reference":"wp-includes\/js\/dist\/a11y.js"}} );
//# sourceURL=wp-a11y-js-translations
</script>
<script src="https://roomguide.kr/wp-includes/js/dist/a11y.min.js?ver=cb460b4676c94bd228ed" id="wp-a11y-js"></script>
<script id="user-profile-js-extra">
var userProfileL10n = {"user_id":"0","nonce":"dd1b64e177"};
//# sourceURL=user-profile-js-extra
</script>
<script id="user-profile-js-translations">
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2026-03-26 00:20:52+0000","generator":"GlotPress\/4.0.3","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=1; plural=0;","lang":"ko_KR"},"Caps lock is on.":["Caps lock\uc774 \ucf1c\uc838 \uc788\uc2b5\ub2c8\ub2e4."],"Application password has been copied to your clipboard.":["\uc560\ud50c\ub9ac\ucf00\uc774\uc158 \ube44\ubc00\ubc88\ud638\uac00 \ud074\ub9bd\ubcf4\ub4dc\uc5d0 \ubcf5\uc0ac\ub418\uc5c8\uc2b5\ub2c8\ub2e4."],"Your new password has not been saved.":["\uc0c8 \ube44\ubc00\ubc88\ud638\uac00 \uc800\uc7a5\ub418\uc9c0 \uc54a\uc558\uc2b5\ub2c8\ub2e4."],"Confirm use of weak password":["\uc57d\ud55c \ube44\ubc00\ubc88\ud638 \uc0ac\uc6a9 \ud655\uc778"],"Hide password":["\ube44\ubc00\ubc88\ud638 \uc228\uae30\uae30"],"Show password":["\ube44\ubc00\ubc88\ud638 \ud45c\uc2dc"],"Hide":["\uc228\uae30\uae30"],"Show":["\ud45c\uc2dc"],"The changes you made will be lost if you navigate away from this page.":["\uc774 \ud398\uc774\uc9c0\uc5d0\uc11c \ub2e4\ub978 \uacf3\uc73c\ub85c \uc774\ub3d9\ud558\uba74 \ubcc0\uacbd \uc0ac\ud56d\uc774 \uc190\uc2e4\ub429\ub2c8\ub2e4."]}},"comment":{"reference":"wp-admin\/js\/user-profile.js"}} );
//# sourceURL=user-profile-js-translations
</script>
<script src="https://roomguide.kr/wp-admin/js/user-profile.min.js?ver=6.9.4" id="user-profile-js"></script>
	</body>
	</html>
	